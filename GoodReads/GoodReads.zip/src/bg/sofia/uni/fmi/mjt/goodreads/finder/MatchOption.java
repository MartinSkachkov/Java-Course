package bg.sofia.uni.fmi.mjt.goodreads.finder;

public enum MatchOption {
    MATCH_ALL,
    MATCH_ANY
}
